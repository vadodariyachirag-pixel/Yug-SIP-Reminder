# YUG SIP Reminder - Android Project V21

This Android WebView project uses the **approved V21 Monthly Sent** web preview exactly as its app content.

Important: V21 is the user's final basic version. Do not change UI, wording, logo, Firebase logic, reminder behavior, or features unless explicitly requested.

The project is prepared but an APK cannot be compiled in this environment because Android SDK/build tools are not installed.
