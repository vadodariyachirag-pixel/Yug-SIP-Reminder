# YUG SIP Reminder V22 — GitHub APK Build

This project is locked to the approved V22 basic version. The Android app embeds the V22 web preview and does not change its UI, wording, logo, Firebase configuration, or reminder logic.

## Build from a tablet with GitHub

1. Create a new GitHub repository.
2. Upload the **contents** of this project (not the outer folder itself).
3. Open the repository's **Actions** tab.
4. Select **Build YUG SIP Reminder APK**.
5. Tap **Run workflow** (or push to `main`, which also triggers it).
6. When the run finishes, open the run and download the artifact named **YUG-SIP-Reminder-V22-debug-apk**.
7. Extract the downloaded artifact ZIP to get `app-debug.apk`.

GitHub-hosted runners provide the build environment, so Android Studio/Android SDK does not need to be installed on the tablet.
