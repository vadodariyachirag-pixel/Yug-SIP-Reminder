# YUG SIP Reminder - Android Project V22

This Android WebView project uses the **approved V22 Monthly Sent** web preview exactly as its app content.

Important: V22 is the user's final basic version. Do not change UI, wording, logo, Firebase logic, reminder behavior, or features unless explicitly requested.

The project is prepared but an APK cannot be compiled in this environment because Android SDK/build tools are not installed.


## V22 WhatsApp Business fix
The Android WebView intercepts WhatsApp click-to-chat URLs and launches the WhatsApp Business Android package (`com.whatsapp.w4b`). The web preview itself cannot force WhatsApp Business; this behavior is native to the APK. The Business account used is the account currently registered in WhatsApp Business on the device (for example, the user's 6352393652 account).
